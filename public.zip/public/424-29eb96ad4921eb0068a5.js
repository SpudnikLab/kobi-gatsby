"use strict";(self.webpackChunkkobi_gatsby=self.webpackChunkkobi_gatsby||[]).push([[424],{4424:function(I,m,t){t.r(m);var e=t(7294),a=t(4462),g=t(6400),x=t(5828);const f=({data:h})=>{let s=h.wpgraphql.posts.nodes,c,i,o;typeof window!="undefined"&&(c=window.location.pathname,i=c.split("/").pop(),o=i.charAt(0).toUpperCase()+i.slice(1));let S=s.length,[r,w]=(0,e.useState)(0),Z=Math.ceil(S/10),j=(0,e.useRef)(null);const z=()=>j.current.scrollIntoView();return e.createElement("div",{ref:j,className:"container"},e.createElement(x.Z,{title:o}),e.createElement("style",null,`
          body {
            margin: 0;
            font-family: "Open Sans", sans-serif;
            font-weight: 100;
          }
          
          a {
            color: black;
            text-decoration: none;
          }
          
          footer {
            margin: 0 0 20px 0;
          }
          
          .header {
            position: fixed;
            width: 100%;z-index: 100;
          }
          
          .pageTitle {
            background-color: #2d5750;
            color: white;
            text-align: center;
            font-size: 14px;
            padding: 5px 0px;
            font-weight: 600;
          }
          
          .paginationHeader {
            background-color: #d9d9d9;
            color: #2d5750;
            text-align: center;
            height: 20px;
            /* text-transform: uppercase; */
            font-size: 14px;
            font-weight: 600;
            padding: 5px 0px;
          }
          
          .searchHeader {
            background-color: #d9d9d9;
            color: #2d5750;
            text-align: center;
            /* text-transform: uppercase; */
            font-size: 14px;
            font-weight: 600;
            padding: 10px;
          }
          
          .pb0{
            padding-bottom: 0;
          }
          
          .contentContainer {
            padding: 45px 0 10px 0;
          }
          
          
          .contentContainer.withPagination {
            padding: 65px 0 10px 0;
          }
          
          .contentContainer.withPagination.search {
            padding: 80px 0 10px 0;
          }
          
          
          .contentContainer.search {
            padding: 60px 0 10px 0;
          }
          
          .innerContent {
            margin-left: auto;
            margin-right: auto;
            max-width: 480px;
          }
          
          
          .appContainer {
            display: flex;
            padding: 15px;
            cursor: pointer;
          }
          
          .appContainer:hover {
            background-color: #d9ffff;
          }
          
          .appIcon {
            height: 35px;
            width: 35px;
            object-fit: contain;
            margin-right: 10px;
          }
          
          .ph{
            padding: 0 10px;
          }
          
          .hide{
            display:none;
          }
          
          .navigationContainer{
            margin: 10px 0;
            display:flex;
            justify-content: space-evenly;
          }
          
          .pr {
            margin-right: 8px;
          }
          
          .footerButton {
            margin-bottom: 5px;
            padding: 8px;
            border: 2px solid teal;
            border-radius: 5px;
            color: teal;
            fill: teal;
            display: flex;
            flex:1;
            align-items: center;
            justify-content: center;
            cursor: pointer;
          }
          
          
          .footerButton.disabled {
            border: 2px solid grey;
            color: grey;
            fill: grey;
            cursor: pointer;
            pointer-events: none;
          }
          
          .footerButton:hover {
            border: 2px solid #2d5750;
            color: #2d5750;
            fill: #2d5750;
            background-color: #f0f0f0;
          }
          
          
          .footerButton:hover.disabled {
            border: 2px solid grey;
            color: grey;
            fill: grey;
            background-color: #ffffff;
            cursor:context-menu;
            pointer-events: none;
          }
          
          .footerIcon {
            height: 15px;
            width: 15px;
            margin-right: 10px;
            fill: #2d5750;
          }
          .footerIcon.right {
            height: 15px;
            width: 15px;
            margin-left: 10px;
            transform: rotateY(180deg);
          }          
        `),e.createElement("header",{className:"header"},e.createElement("div",{className:"pageTitle"},e.createElement("div",{className:"innerContent"},e.createElement(g.Z,{component:"h1"},o))),e.createElement("div",{className:`${Z>1?"paginationHeader":"hide"}`},e.createElement("div",{className:"innerContent"},"Page ",r+1," / ",Z))),e.createElement("div",{className:`contentContainer ${Z>1?"withPagination":null}`},e.createElement("div",{className:"innerContent ph"},e.createElement("div",{className:`${Z>1?"navigationContainer":"hide"}`},e.createElement("div",{className:`footerButton flex pr ${r===0?"disabled":"null"}`,onClick:()=>r>0?w(r-1):null},e.createElement("svg",{className:"footerIcon",version:"1.1",id:"arrow-back",x:"0px",y:"0px",viewBox:"0 0 16 16"},e.createElement("g",{id:"arrow-back-icon"},e.createElement("path",{d:"M16,7H3.8l5.6-5.6L8,0L0,8l8,8l1.4-1.4L3.8,9H16V7z"}))),e.createElement("div",null,"Previous")),e.createElement("div",{className:`footerButton flex ${r+1===Z?"disabled":"null"}`,onClick:()=>r+1<Z?w(r+1):null},e.createElement("div",null,"Next"),e.createElement("svg",{className:"footerIcon right",version:"1.1",id:"arrow-back",x:"0px",y:"0px",viewBox:"0 0 16 16"},e.createElement("g",{id:"arrow-back-icon"},e.createElement("path",{d:"M16,7H3.8l5.6-5.6L8,0L0,8l8,8l1.4-1.4L3.8,9H16V7z"})))))),e.createElement("div",{className:"innerContent"},s.slice(r*10,r*10+10).map(P=>{var W,H;return e.createElement(a.Link,{key:P.slug,to:`/${P.slug}`,state:{prevPath:"/search"}},e.createElement("div",{className:"appContainer"},e.createElement("img",{src:(H=(W=P.featuredImage)==null?void 0:W.node)==null?void 0:H.mediaItemUrl,alt:P.title,className:"appIcon"}),e.createElement("div",null,e.createElement(g.Z,{sx:{fontSize:16,lineHeight:"20px",fontWeight:600}},P.title),e.createElement(g.Z,{sx:{fontSize:14}},P.excerpt.replace(/<\/?[^>]+(>|$)/g,"")),e.createElement("div",{className:`rating rate-${P.appFields.overallRating}`}))))})),e.createElement("div",{className:"innerContent ph"},e.createElement("div",{className:`${Z>1?"navigationContainer":"hide"}`},e.createElement("div",{className:`footerButton flex pr ${r===0?"disabled":"null"}`,onClick:()=>r>0?w(r-1):null},e.createElement("svg",{className:"footerIcon",version:"1.1",id:"arrow-back",x:"0px",y:"0px",viewBox:"0 0 16 16"},e.createElement("g",{id:"arrow-back-icon"},e.createElement("path",{d:"M16,7H3.8l5.6-5.6L8,0L0,8l8,8l1.4-1.4L3.8,9H16V7z"}))),e.createElement("div",null,"Previous")),e.createElement("div",{className:`footerButton flex ${r+1===Z?"disabled":"null"}`,onClick:()=>r+1<Z?w(r+1):null},e.createElement("div",null,"Next"),e.createElement("svg",{className:"footerIcon right",version:"1.1",id:"arrow-back",x:"0px",y:"0px",viewBox:"0 0 16 16"},e.createElement("g",{id:"arrow-back-icon"},e.createElement("path",{d:"M16,7H3.8l5.6-5.6L8,0L0,8l8,8l1.4-1.4L3.8,9H16V7z"}))))))),e.createElement("footer",null,e.createElement("div",{className:"innerContent"},e.createElement(a.Link,{to:"/"},e.createElement("div",{className:"footerButton"},e.createElement("svg",{className:"footerIcon",version:"1.1",id:"arrow-back",x:"0px",y:"0px",viewBox:"0 0 16 16"},e.createElement("g",{id:"arrow-back-icon"},e.createElement("path",{d:"M16,7H3.8l5.6-5.6L8,0L0,8l8,8l1.4-1.4L3.8,9H16V7z"}))),e.createElement("div",null,"Back to Home"))),e.createElement("div",{className:"footerButton",onClick:z},e.createElement("svg",{className:"footerIcon",x:"0px",y:"0px",viewBox:"0 0 16 16"},e.createElement("g",null,e.createElement("path",{d:"M0.5,8l1.41,1.41L7.5,3.83V16h2V3.83l5.58,5.59L16.5,8l-8-8L0.5,8z"}))),e.createElement("div",null,"Top of Page")))))},C="3878579991";m.default=f},6400:function(I,m,t){t.d(m,{Z:function(){return Y}});var e=t(4425),a=t(6370),g=t(7294),x=t(1497),f=t(877),C=t(6530),h=t(8883),s=t(1430),c=t(370),i=t(132),o=t(5848);function S(b){return(0,o.Z)("MuiTypography",b)}const r=(0,i.Z)("MuiTypography",["root","h1","h2","h3","h4","h5","h6","subtitle1","subtitle2","body1","body2","inherit","button","caption","overline","alignLeft","alignRight","alignCenter","alignJustify","noWrap","gutterBottom","paragraph"]);var w=null,Z=t(5893);const j=["align","className","component","gutterBottom","noWrap","paragraph","variant","variantMapping"],z=b=>{const{align:p,gutterBottom:T,noWrap:n,paragraph:l,variant:y,classes:v}=b,d={root:["root",y,b.align!=="inherit"&&`align${(0,c.Z)(p)}`,T&&"gutterBottom",n&&"noWrap",l&&"paragraph"]};return(0,C.Z)(d,S,v)},P=(0,h.ZP)("span",{name:"MuiTypography",slot:"Root",overridesResolver:(b,p)=>{const{ownerState:T}=b;return[p.root,T.variant&&p[T.variant],T.align!=="inherit"&&p[`align${(0,c.Z)(T.align)}`],T.noWrap&&p.noWrap,T.gutterBottom&&p.gutterBottom,T.paragraph&&p.paragraph]}})(({theme:b,ownerState:p})=>(0,a.Z)({margin:0},p.variant&&b.typography[p.variant],p.align!=="inherit"&&{textAlign:p.align},p.noWrap&&{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},p.gutterBottom&&{marginBottom:"0.35em"},p.paragraph&&{marginBottom:16})),W={h1:"h1",h2:"h2",h3:"h3",h4:"h4",h5:"h5",h6:"h6",subtitle1:"h6",subtitle2:"h6",body1:"p",body2:"p",inherit:"p"},H={primary:"primary.main",textPrimary:"text.primary",secondary:"secondary.main",textSecondary:"text.secondary",error:"error.main"},J=b=>H[b]||b;var Y=g.forwardRef(function(p,T){const n=(0,s.Z)({props:p,name:"MuiTypography"}),l=J(n.color),y=(0,f.Z)((0,a.Z)({},n,{color:l})),{align:v="inherit",className:d,component:E,gutterBottom:k=!1,noWrap:M=!1,paragraph:L=!1,variant:B="body1",variantMapping:D=W}=y,$=(0,e.Z)(y,j),F=(0,a.Z)({},y,{align:v,color:l,className:d,component:E,gutterBottom:k,noWrap:M,paragraph:L,variant:B,variantMapping:D}),Q=E||(L?"p":D[B]||W[B])||"span",X=z(F);return(0,Z.jsx)(P,(0,a.Z)({as:Q,ref:T,ownerState:F,className:(0,x.Z)(X.root,d)},$))})},2275:function(I,m,t){var e=t(3888);const a=(0,e.Z)();m.Z=a},8883:function(I,m,t){t.d(m,{ZP:function(){return T}});var e=t(4425),a=t(6370),g=t(4491),x=t(4189),f=t(1103);const C=["variant"];function h(n){return n.length===0}function s(n){const{variant:l}=n,y=(0,e.Z)(n,C);let v=l||"";return Object.keys(y).sort().forEach(d=>{d==="color"?v+=h(v)?n[d]:(0,f.Z)(n[d]):v+=`${h(v)?d:(0,f.Z)(d)}${(0,f.Z)(n[d].toString())}`}),v}var c=t(3366);const i=["name","slot","skipVariantsResolver","skipSx","overridesResolver"],o=["theme"],S=["theme"];function r(n){return Object.keys(n).length===0}function w(n){return typeof n=="string"&&n.charCodeAt(0)>96}const Z=(n,l)=>l.components&&l.components[n]&&l.components[n].styleOverrides?l.components[n].styleOverrides:null,j=(n,l)=>{let y=[];l&&l.components&&l.components[n]&&l.components[n].variants&&(y=l.components[n].variants);const v={};return y.forEach(d=>{const E=s(d.props);v[E]=d.style}),v},z=(n,l,y,v)=>{var d,E;const{ownerState:k={}}=n,M=[],L=y==null||(d=y.components)==null||(E=d[v])==null?void 0:E.variants;return L&&L.forEach(B=>{let D=!0;Object.keys(B.props).forEach($=>{k[$]!==B.props[$]&&n[$]!==B.props[$]&&(D=!1)}),D&&M.push(l[s(B.props)])}),M};function P(n){return n!=="ownerState"&&n!=="theme"&&n!=="sx"&&n!=="as"}const W=(0,x.Z)(),H=n=>n.charAt(0).toLowerCase()+n.slice(1);function J(n={}){const{defaultTheme:l=W,rootShouldForwardProp:y=P,slotShouldForwardProp:v=P}=n,d=E=>{const k=r(E.theme)?l:E.theme;return(0,c.Z)((0,a.Z)({},E,{theme:k}))};return d.__mui_systemSx=!0,(E,k={})=>{(0,g.Co)(E,R=>R.filter(U=>!(U!=null&&U.__mui_systemSx)));const{name:M,slot:L,skipVariantsResolver:B,skipSx:D,overridesResolver:$}=k,F=(0,e.Z)(k,i),Q=B!==void 0?B:L&&L!=="Root"||!1,X=D||!1;let oe,K=P;L==="Root"?K=y:L?K=v:w(E)&&(K=void 0);const _=(0,g.ZP)(E,(0,a.Z)({shouldForwardProp:K,label:oe},F)),te=(R,...U)=>{const V=U?U.map(u=>typeof u=="function"&&u.__emotion_real!==u?O=>{let{theme:N}=O,G=(0,e.Z)(O,o);return u((0,a.Z)({theme:r(N)?l:N},G))}:u):[];let A=R;M&&$&&V.push(u=>{const O=r(u.theme)?l:u.theme,N=Z(M,O);if(N){const G={};return Object.entries(N).forEach(([re,q])=>{G[re]=typeof q=="function"?q((0,a.Z)({},u,{theme:O})):q}),$(u,G)}return null}),M&&!Q&&V.push(u=>{const O=r(u.theme)?l:u.theme;return z(u,j(M,O),O,M)}),X||V.push(d);const ne=V.length-U.length;if(Array.isArray(R)&&ne>0){const u=new Array(ne).fill("");A=[...R,...u],A.raw=[...R.raw,...u]}else typeof R=="function"&&R.__emotion_real!==R&&(A=u=>{let{theme:O}=u,N=(0,e.Z)(u,S);return R((0,a.Z)({theme:r(O)?l:O},N))});return _(A,...V)};return _.withConfig&&(te.withConfig=_.withConfig),te}}var ee=t(2275);const Y=n=>P(n)&&n!=="classes",b=null;var T=J({defaultTheme:ee.Z,rootShouldForwardProp:Y})},1430:function(I,m,t){t.d(m,{Z:function(){return h}});var e=t(6370);function a(s,c){const i=(0,e.Z)({},c);return Object.keys(s).forEach(o=>{if(o.toString().match(/^(components|slots)$/))i[o]=(0,e.Z)({},s[o],i[o]);else if(o.toString().match(/^(componentsProps|slotProps)$/)){const S=s[o]||{},r=c[o];i[o]={},!r||!Object.keys(r)?i[o]=S:!S||!Object.keys(S)?i[o]=r:(i[o]=(0,e.Z)({},r),Object.keys(S).forEach(w=>{i[o][w]=a(S[w],r[w])}))}else i[o]===void 0&&(i[o]=s[o])}),i}function g(s){const{theme:c,name:i,props:o}=s;return!c||!c.components||!c.components[i]||!c.components[i].defaultProps?o:a(c.components[i].defaultProps,o)}var x=t(8097);function f({props:s,name:c,defaultTheme:i}){const o=(0,x.Z)(i);return g({theme:o,name:c,props:s})}var C=t(2275);function h({props:s,name:c}){return f({props:s,name:c,defaultTheme:C.Z})}},370:function(I,m,t){var e=t(1103);m.Z=e.Z},6530:function(I,m,t){t.d(m,{Z:function(){return e}});function e(a,g,x=void 0){const f={};return Object.keys(a).forEach(C=>{f[C]=a[C].reduce((h,s)=>{if(s){const c=g(s);c!==""&&h.push(c),x&&x[s]&&h.push(x[s])}return h},[]).join(" ")}),f}},5848:function(I,m,t){t.d(m,{Z:function(){return g}});var e=t(1864);const a={active:"active",checked:"checked",completed:"completed",disabled:"disabled",readOnly:"readOnly",error:"error",expanded:"expanded",focused:"focused",focusVisible:"focusVisible",required:"required",selected:"selected"};function g(x,f,C="Mui"){const h=a[f];return h?`${C}-${h}`:`${e.Z.generate(x)}-${f}`}},132:function(I,m,t){t.d(m,{Z:function(){return a}});var e=t(5848);function a(g,x,f="Mui"){const C={};return x.forEach(h=>{C[h]=(0,e.Z)(g,h,f)}),C}}}]);

//# sourceMappingURL=424-29eb96ad4921eb0068a5.js.map