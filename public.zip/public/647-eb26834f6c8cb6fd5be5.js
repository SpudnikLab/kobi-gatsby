"use strict";(self.webpackChunkkobi_gatsby=self.webpackChunkkobi_gatsby||[]).push([[647],{2647:function(F,E,t){t.r(E),t.d(E,{default:function(){return ae}});var n=t(7294),d=t(4462),W=t(357),T=t(4425),Z=t(6370),B=t(1497),f=t(9710),x=t(877),v=t(6530),y=t(8883),m=t(1430),N=t(8097),R=t(2275);function I(){return(0,N.Z)(R.Z)}var J=n.createContext(),Q=t(132),V=t(5848);function H(e){return(0,V.Z)("MuiGrid",e)}const X=[0,1,2,3,4,5,6,7,8,9,10],Y=["column-reverse","column","row-reverse","row"],ne=["nowrap","wrap-reverse","wrap"],w=["auto",!0,1,2,3,4,5,6,7,8,9,10,11,12];var p=(0,Q.Z)("MuiGrid",["root","container","item","zeroMinWidth",...X.map(e=>`spacing-xs-${e}`),...Y.map(e=>`direction-xs-${e}`),...ne.map(e=>`wrap-xs-${e}`),...w.map(e=>`grid-xs-${e}`),...w.map(e=>`grid-sm-${e}`),...w.map(e=>`grid-md-${e}`),...w.map(e=>`grid-lg-${e}`),...w.map(e=>`grid-xl-${e}`)]),$=t(5893);const r=["className","columns","columnSpacing","component","container","direction","item","rowSpacing","spacing","wrap","zeroMinWidth"];function c(e){const o=parseFloat(e);return`${o}${String(e).replace(String(o),"")||"px"}`}function P({theme:e,ownerState:o}){let a;return e.breakpoints.keys.reduce((s,i)=>{let u={};if(o[i]&&(a=o[i]),!a)return s;if(a===!0)u={flexBasis:0,flexGrow:1,maxWidth:"100%"};else if(a==="auto")u={flexBasis:"auto",flexGrow:0,flexShrink:0,maxWidth:"none",width:"auto"};else{const O=(0,f.P$)({values:o.columns,breakpoints:e.breakpoints.values}),l=typeof O=="object"?O[i]:O;if(l==null)return s;const h=`${Math.round(a/l*1e8)/1e6}%`;let C={};if(o.container&&o.item&&o.columnSpacing!==0){const g=e.spacing(o.columnSpacing);if(g!=="0px"){const K=`calc(${h} + ${c(g)})`;C={flexBasis:K,maxWidth:K}}}u=(0,Z.Z)({flexBasis:h,flexGrow:0,maxWidth:h},C)}return e.breakpoints.values[i]===0?Object.assign(s,u):s[e.breakpoints.up(i)]=u,s},{})}function b({theme:e,ownerState:o}){const a=(0,f.P$)({values:o.direction,breakpoints:e.breakpoints.values});return(0,f.k9)({theme:e},a,s=>{const i={flexDirection:s};return s.indexOf("column")===0&&(i[`& > .${p.item}`]={maxWidth:"none"}),i})}function S({breakpoints:e,values:o}){let a="";Object.keys(o).forEach(i=>{a===""&&o[i]!==0&&(a=i)});const s=Object.keys(e).sort((i,u)=>e[i]-e[u]);return s.slice(0,s.indexOf(a))}function M({theme:e,ownerState:o}){const{container:a,rowSpacing:s}=o;let i={};if(a&&s!==0){const u=(0,f.P$)({values:s,breakpoints:e.breakpoints.values});let O;typeof u=="object"&&(O=S({breakpoints:e.breakpoints.values,values:u})),i=(0,f.k9)({theme:e},u,(l,h)=>{var C;const g=e.spacing(l);return g!=="0px"?{marginTop:`-${c(g)}`,[`& > .${p.item}`]:{paddingTop:c(g)}}:(C=O)!=null&&C.includes(h)?{}:{marginTop:0,[`& > .${p.item}`]:{paddingTop:0}}})}return i}function U({theme:e,ownerState:o}){const{container:a,columnSpacing:s}=o;let i={};if(a&&s!==0){const u=(0,f.P$)({values:s,breakpoints:e.breakpoints.values});let O;typeof u=="object"&&(O=S({breakpoints:e.breakpoints.values,values:u})),i=(0,f.k9)({theme:e},u,(l,h)=>{var C;const g=e.spacing(l);return g!=="0px"?{width:`calc(100% + ${c(g)})`,marginLeft:`-${c(g)}`,[`& > .${p.item}`]:{paddingLeft:c(g)}}:(C=O)!=null&&C.includes(h)?{}:{width:"100%",marginLeft:0,[`& > .${p.item}`]:{paddingLeft:0}}})}return i}function z(e,o,a={}){if(!e||e<=0)return[];if(typeof e=="string"&&!Number.isNaN(Number(e))||typeof e=="number")return[a[`spacing-xs-${String(e)}`]];const s=[];return o.forEach(i=>{const u=e[i];Number(u)>0&&s.push(a[`spacing-${i}-${String(u)}`])}),s}const L=(0,y.ZP)("div",{name:"MuiGrid",slot:"Root",overridesResolver:(e,o)=>{const{ownerState:a}=e,{container:s,direction:i,item:u,spacing:O,wrap:l,zeroMinWidth:h,breakpoints:C}=a;let g=[];s&&(g=z(O,C,o));const K=[];return C.forEach(k=>{const _=a[k];_&&K.push(o[`grid-${k}-${String(_)}`])}),[o.root,s&&o.container,u&&o.item,h&&o.zeroMinWidth,...g,i!=="row"&&o[`direction-xs-${String(i)}`],l!=="wrap"&&o[`wrap-xs-${String(l)}`],...K]}})(({ownerState:e})=>(0,Z.Z)({boxSizing:"border-box"},e.container&&{display:"flex",flexWrap:"wrap",width:"100%"},e.item&&{margin:0},e.zeroMinWidth&&{minWidth:0},e.wrap!=="wrap"&&{flexWrap:e.wrap}),b,M,U,P);function G(e,o){if(!e||e<=0)return[];if(typeof e=="string"&&!Number.isNaN(Number(e))||typeof e=="number")return[`spacing-xs-${String(e)}`];const a=[];return o.forEach(s=>{const i=e[s];if(Number(i)>0){const u=`spacing-${s}-${String(i)}`;a.push(u)}}),a}const A=e=>{const{classes:o,container:a,direction:s,item:i,spacing:u,wrap:O,zeroMinWidth:l,breakpoints:h}=e;let C=[];a&&(C=G(u,h));const g=[];h.forEach(k=>{const _=e[k];_&&g.push(`grid-${k}-${String(_)}`)});const K={root:["root",a&&"container",i&&"item",l&&"zeroMinWidth",...C,s!=="row"&&`direction-xs-${String(s)}`,O!=="wrap"&&`wrap-xs-${String(O)}`,...g]};return(0,v.Z)(K,H,o)};var q=n.forwardRef(function(o,a){const s=(0,m.Z)({props:o,name:"MuiGrid"}),{breakpoints:i}=I(),u=(0,x.Z)(s),{className:O,columns:l,columnSpacing:h,component:C="div",container:g=!1,direction:K="row",item:k=!1,rowSpacing:_,spacing:le=0,wrap:fe="wrap",zeroMinWidth:he=!1}=u,ce=(0,T.Z)(u,r),ge=_||le,xe=h||le,ve=n.useContext(J),ue=g?l||12:ve,de={},me=(0,Z.Z)({},ce);i.keys.forEach(se=>{ce[se]!=null&&(de[se]=ce[se],delete me[se])});const pe=(0,Z.Z)({},u,{columns:ue,container:g,direction:K,item:k,rowSpacing:ge,columnSpacing:xe,wrap:fe,zeroMinWidth:he,spacing:le},de,{breakpoints:i.keys}),ye=A(pe);return(0,$.jsx)(J.Provider,{value:ue,children:(0,$.jsx)(L,(0,Z.Z)({ownerState:pe,className:(0,B.Z)(ye.root,O),as:C,ref:a},me))})}),ee=t(6400),oe=t(5828);const ie=({data:e})=>{let o=e.wpgraphql.categories.nodes;return n.createElement("div",null,n.createElement(oe.Z,{title:"Kobi"}),n.createElement("style",null,`
          body {
            margin: 0;
            font-family:'Open Sans', sans-serif;
            font-weight: 100;
            font-size: 15px;
          }
          
          a{
            color: black;
            text-decoration: none;
          }
          
          footer{
            margin-top: 10px;
            text-align: center;
            padding:0 10px;
            display:"flex";
            flex-direction: column;
          }
          
          .appHeader {
            background-color: #2d5750;
          }
          
          .titleContainer{
            padding: 10px;
            height:60px;
            display: flex;
            align-items: center;
            color: white;
          }
          
          .logoContainer{
            min-height:58px;
            max-height: 58px;
            min-width:58px;
            max-width: 58px;
            border-radius: 5px;
            overflow: hidden;
            margin-right: 10px;
            background: url(https://demo-kobi-gokart.netlify.app/static/Kobi_Logo-75c3f61b32a9490ac733a26ee2376d69.svg);
          }
          .logoContainer2 {
            min-height: 150px;
            max-height: 150px;
            min-width: 150px;
            max-width: 150px;
            margin-left: auto;
            margin-right: auto;
            border-radius: 5px;
            background: url(https://demo-kobi-gokart.netlify.app/static/Kobi_Logo-75c3f61b32a9490ac733a26ee2376d69.svg);
            background-size: contain;
            background-repeat: no-repeat;
          }
          
          
          
          .textContainer{
            flex:1;
          }
          
          .categoriesHeader {
            background-color: #d9d9d9;
            color: #2d5750;
            text-align: center;
            text-transform: uppercase;
            font-size: 14px;
            font-weight: 600;
            padding: 5px 0px;
          }
          
          .innerContent {
            margin-left: auto;
            margin-right: auto;
            max-width: 480px;
          }
          
          .categoryContainer{
              padding: 10px 0
          }
          
          .categoriesButton {
              padding:5px;
              display: flex;
              flex-direction: column;
              align-items: center;
              font-size: 15px;
              line-height: 24px;
              cursor: pointer;
          }
          
          .categoriesButton:hover{
          background-color: #d9ffff;
          }
          
          .categoriesIcon{
              height: 30px;
              width: 30px;
              object-fit: contain;
          }
          
          .aboutButton{
            display: inline-block;
            background-color: teal;
            padding:10px;
            color:white;
            border-radius: 5px;
          }
          .aboutButton:hover{
            background-color: #2d5750;
          }
          
          .arrowContainer{
            min-height:24px;
            max-height: 24px;
            min-width:24px;
            max-width: 24px;
            margin-left: auto;
            margin-right: 40px;
            margin-top: 5px;
            background: url(../images/Arrow.svg);
            background-repeat: no-repeat;
          }
          .footerIcon {
            height: 15px;
            width: 15px;
            margin-right: 10px;
            fill: #2d5750;
          }
          
          .searchButton {
            margin: 0 10px 15px;
            padding: 8px;
            border: 2px solid teal;
            border-radius: 5px;
            color: teal;
            fill: teal;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
          }
          .searchButton:hover {
            border: 2px solid #2d5750;
            color: #2d5750;
            fill: #2d5750;
            background-color: #f0f0f0;
          }
        `),n.createElement("header",null,n.createElement("div",{className:"appHeader"},n.createElement("div",{className:"innerContent"},n.createElement("div",{className:"titleContainer"},n.createElement("div",{className:"logoContainer"}),n.createElement("div",{className:"textContainer"},n.createElement(ee.Z,{sx:{fontSize:24,lineHeight:"24px"},component:"h1"},"Kobi"),n.createElement(ee.Z,{sx:{fontSize:15,lineHeight:"15px"},component:"small"},"Here to help you find useful apps"))))),n.createElement("div",{className:"categoriesHeader"},n.createElement("div",{className:"innerContent"},"Categories"))),n.createElement("div",{className:"categoryContainer"},n.createElement("div",{className:"innerContent"},n.createElement("section",null,n.createElement(q,{container:!0,sx:{marginBottom:"10px"}},o.map(a=>{var s;if(a.customCategories.icon)return n.createElement(q,{item:!0,xs:6,key:a.slug},n.createElement(d.Link,{to:`/categories/${a.slug}`,className:"link"},n.createElement("div",{className:"categoriesButton"},n.createElement("img",{src:(s=a.customCategories.icon)==null?void 0:s.mediaItemUrl,alt:a.name,className:"categoriesIcon"}),a.name)))})),n.createElement(d.Link,{to:"/search/"},n.createElement("div",{className:"searchButton"},n.createElement("svg",{className:"footerIcon",version:"1.1",id:"arrow-back",x:"0px",y:"0px",viewBox:"0 0 488 488"},n.createElement("g",null,n.createElement("g",null,n.createElement("path",{d:`M488,445c-45.3-45.7-90.6-91.3-136-137c8.9-14.9,20.9-38.4,28-69.2c0,0,6-24.7,6-47.5C386,85.9,299.5,0.2,193.1,0.2\r
                        S0,86,0,191.4s86.5,191.1,192.9,191.1c26.6,0,52.6-7.2,52.6-7.2c24.7-6.9,43.3-17.5,55.3-25.5c47.7,46.1,95.5,92.1,143.2,138.2\r
                        c10.4,1.9,18.5,0.8,23.5-0.2c5.7-1.2,10.4-2.2,14.3-6.1c4-4,5-8.7,6.1-14.3C488.9,462.6,489.9,454.8,488,445z M64.5,191.2\r
                        c0-71.1,58.6-129,130.5-129s130.5,57.8,130.5,129s-58.6,129-130.5,129S64.5,262.2,64.5,191.2z`})))),n.createElement("div",null,"Search")))),n.createElement("footer",null,n.createElement("p",null,"Kobi finds apps that help you live a better life."),n.createElement(d.Link,{to:"/about"},n.createElement("div",{className:"aboutButton"},"Learn about Kobi")),n.createElement(W.Z,{sx:{display:{xs:"block",sm:"none"},width:"180px",marginRight:"auto",marginLeft:"auto",fontSize:14,mt:2}},n.createElement("span",null,"Enjoying Kobi? Press Options & Pin to Top Sites!"),n.createElement("div",{className:"arrowContainer"}))))))},re="185051467";var ae=ie},357:function(F,E,t){t.d(E,{Z:function(){return J}});var n=t(6370),d=t(4425),W=t(7294),T=t(1497),Z=t(4491),B=t(3366),f=t(877),x=t(8097),v=t(5893);const y=["className","component"];function m(Q={}){const{defaultTheme:V,defaultClassName:H="MuiBox-root",generateClassName:X}=Q,Y=(0,Z.ZP)("div",{shouldForwardProp:w=>w!=="theme"&&w!=="sx"&&w!=="as"})(B.Z);return W.forwardRef(function(j,p){const $=(0,x.Z)(V),r=(0,f.Z)(j),{className:c,component:P="div"}=r,b=(0,d.Z)(r,y);return(0,v.jsx)(Y,(0,n.Z)({as:P,ref:p,className:(0,T.Z)(c,X?X(H):H),theme:$},b))})}var N=t(1864),R=t(3888);const I=(0,R.Z)();var J=m({defaultTheme:I,defaultClassName:"MuiBox-root",generateClassName:N.Z.generate})},6400:function(F,E,t){t.d(E,{Z:function(){return w}});var n=t(4425),d=t(6370),W=t(7294),T=t(1497),Z=t(877),B=t(6530),f=t(8883),x=t(1430),v=t(370),y=t(132),m=t(5848);function N(j){return(0,m.Z)("MuiTypography",j)}const R=(0,y.Z)("MuiTypography",["root","h1","h2","h3","h4","h5","h6","subtitle1","subtitle2","body1","body2","inherit","button","caption","overline","alignLeft","alignRight","alignCenter","alignJustify","noWrap","gutterBottom","paragraph"]);var I=null,te=t(5893);const J=["align","className","component","gutterBottom","noWrap","paragraph","variant","variantMapping"],Q=j=>{const{align:p,gutterBottom:$,noWrap:r,paragraph:c,variant:P,classes:b}=j,S={root:["root",P,j.align!=="inherit"&&`align${(0,v.Z)(p)}`,$&&"gutterBottom",r&&"noWrap",c&&"paragraph"]};return(0,B.Z)(S,N,b)},V=(0,f.ZP)("span",{name:"MuiTypography",slot:"Root",overridesResolver:(j,p)=>{const{ownerState:$}=j;return[p.root,$.variant&&p[$.variant],$.align!=="inherit"&&p[`align${(0,v.Z)($.align)}`],$.noWrap&&p.noWrap,$.gutterBottom&&p.gutterBottom,$.paragraph&&p.paragraph]}})(({theme:j,ownerState:p})=>(0,d.Z)({margin:0},p.variant&&j.typography[p.variant],p.align!=="inherit"&&{textAlign:p.align},p.noWrap&&{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},p.gutterBottom&&{marginBottom:"0.35em"},p.paragraph&&{marginBottom:16})),H={h1:"h1",h2:"h2",h3:"h3",h4:"h4",h5:"h5",h6:"h6",subtitle1:"h6",subtitle2:"h6",body1:"p",body2:"p",inherit:"p"},X={primary:"primary.main",textPrimary:"text.primary",secondary:"secondary.main",textSecondary:"text.secondary",error:"error.main"},Y=j=>X[j]||j;var w=W.forwardRef(function(p,$){const r=(0,x.Z)({props:p,name:"MuiTypography"}),c=Y(r.color),P=(0,Z.Z)((0,d.Z)({},r,{color:c})),{align:b="inherit",className:S,component:M,gutterBottom:U=!1,noWrap:z=!1,paragraph:L=!1,variant:G="body1",variantMapping:A=H}=P,D=(0,n.Z)(P,J),q=(0,d.Z)({},P,{align:b,color:c,className:S,component:M,gutterBottom:U,noWrap:z,paragraph:L,variant:G,variantMapping:A}),ee=M||(L?"p":A[G]||H[G])||"span",oe=Q(q);return(0,te.jsx)(V,(0,d.Z)({as:ee,ref:$,ownerState:q,className:(0,T.Z)(oe.root,S)},D))})},2275:function(F,E,t){var n=t(3888);const d=(0,n.Z)();E.Z=d},8883:function(F,E,t){t.d(E,{ZP:function(){return $}});var n=t(4425),d=t(6370),W=t(4491),T=t(4189),Z=t(1103);const B=["variant"];function f(r){return r.length===0}function x(r){const{variant:c}=r,P=(0,n.Z)(r,B);let b=c||"";return Object.keys(P).sort().forEach(S=>{S==="color"?b+=f(b)?r[S]:(0,Z.Z)(r[S]):b+=`${f(b)?S:(0,Z.Z)(S)}${(0,Z.Z)(r[S].toString())}`}),b}var v=t(3366);const y=["name","slot","skipVariantsResolver","skipSx","overridesResolver"],m=["theme"],N=["theme"];function R(r){return Object.keys(r).length===0}function I(r){return typeof r=="string"&&r.charCodeAt(0)>96}const te=(r,c)=>c.components&&c.components[r]&&c.components[r].styleOverrides?c.components[r].styleOverrides:null,J=(r,c)=>{let P=[];c&&c.components&&c.components[r]&&c.components[r].variants&&(P=c.components[r].variants);const b={};return P.forEach(S=>{const M=x(S.props);b[M]=S.style}),b},Q=(r,c,P,b)=>{var S,M;const{ownerState:U={}}=r,z=[],L=P==null||(S=P.components)==null||(M=S[b])==null?void 0:M.variants;return L&&L.forEach(G=>{let A=!0;Object.keys(G.props).forEach(D=>{U[D]!==G.props[D]&&r[D]!==G.props[D]&&(A=!1)}),A&&z.push(c[x(G.props)])}),z};function V(r){return r!=="ownerState"&&r!=="theme"&&r!=="sx"&&r!=="as"}const H=(0,T.Z)(),X=r=>r.charAt(0).toLowerCase()+r.slice(1);function Y(r={}){const{defaultTheme:c=H,rootShouldForwardProp:P=V,slotShouldForwardProp:b=V}=r,S=M=>{const U=R(M.theme)?c:M.theme;return(0,v.Z)((0,d.Z)({},M,{theme:U}))};return S.__mui_systemSx=!0,(M,U={})=>{(0,W.Co)(M,o=>o.filter(a=>!(a!=null&&a.__mui_systemSx)));const{name:z,slot:L,skipVariantsResolver:G,skipSx:A,overridesResolver:D}=U,q=(0,n.Z)(U,y),ee=G!==void 0?G:L&&L!=="Root"||!1,oe=A||!1;let ie,re=V;L==="Root"?re=P:L?re=b:I(M)&&(re=void 0);const ae=(0,W.ZP)(M,(0,d.Z)({shouldForwardProp:re,label:ie},q)),e=(o,...a)=>{const s=a?a.map(l=>typeof l=="function"&&l.__emotion_real!==l?h=>{let{theme:C}=h,g=(0,n.Z)(h,m);return l((0,d.Z)({theme:R(C)?c:C},g))}:l):[];let i=o;z&&D&&s.push(l=>{const h=R(l.theme)?c:l.theme,C=te(z,h);if(C){const g={};return Object.entries(C).forEach(([K,k])=>{g[K]=typeof k=="function"?k((0,d.Z)({},l,{theme:h})):k}),D(l,g)}return null}),z&&!ee&&s.push(l=>{const h=R(l.theme)?c:l.theme;return Q(l,J(z,h),h,z)}),oe||s.push(S);const u=s.length-a.length;if(Array.isArray(o)&&u>0){const l=new Array(u).fill("");i=[...o,...l],i.raw=[...o.raw,...l]}else typeof o=="function"&&o.__emotion_real!==o&&(i=l=>{let{theme:h}=l,C=(0,n.Z)(l,N);return o((0,d.Z)({theme:R(h)?c:h},C))});return ae(i,...s)};return ae.withConfig&&(e.withConfig=ae.withConfig),e}}var ne=t(2275);const w=r=>V(r)&&r!=="classes",j=null;var $=Y({defaultTheme:ne.Z,rootShouldForwardProp:w})},1430:function(F,E,t){t.d(E,{Z:function(){return f}});var n=t(6370);function d(x,v){const y=(0,n.Z)({},v);return Object.keys(x).forEach(m=>{if(m.toString().match(/^(components|slots)$/))y[m]=(0,n.Z)({},x[m],y[m]);else if(m.toString().match(/^(componentsProps|slotProps)$/)){const N=x[m]||{},R=v[m];y[m]={},!R||!Object.keys(R)?y[m]=N:!N||!Object.keys(N)?y[m]=R:(y[m]=(0,n.Z)({},R),Object.keys(N).forEach(I=>{y[m][I]=d(N[I],R[I])}))}else y[m]===void 0&&(y[m]=x[m])}),y}function W(x){const{theme:v,name:y,props:m}=x;return!v||!v.components||!v.components[y]||!v.components[y].defaultProps?m:d(v.components[y].defaultProps,m)}var T=t(8097);function Z({props:x,name:v,defaultTheme:y}){const m=(0,T.Z)(y);return W({theme:m,name:v,props:x})}var B=t(2275);function f({props:x,name:v}){return Z({props:x,name:v,defaultTheme:B.Z})}},370:function(F,E,t){var n=t(1103);E.Z=n.Z},6530:function(F,E,t){t.d(E,{Z:function(){return n}});function n(d,W,T=void 0){const Z={};return Object.keys(d).forEach(B=>{Z[B]=d[B].reduce((f,x)=>{if(x){const v=W(x);v!==""&&f.push(v),T&&T[x]&&f.push(T[x])}return f},[]).join(" ")}),Z}},5848:function(F,E,t){t.d(E,{Z:function(){return W}});var n=t(1864);const d={active:"active",checked:"checked",completed:"completed",disabled:"disabled",readOnly:"readOnly",error:"error",expanded:"expanded",focused:"focused",focusVisible:"focusVisible",required:"required",selected:"selected"};function W(T,Z,B="Mui"){const f=d[Z];return f?`${B}-${f}`:`${n.Z.generate(T)}-${Z}`}},132:function(F,E,t){t.d(E,{Z:function(){return d}});var n=t(5848);function d(W,T,Z="Mui"){const B={};return T.forEach(f=>{B[f]=(0,n.Z)(W,f,Z)}),B}}}]);

//# sourceMappingURL=647-eb26834f6c8cb6fd5be5.js.map