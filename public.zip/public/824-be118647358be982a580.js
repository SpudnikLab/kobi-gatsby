"use strict";(self.webpackChunkkobi_gatsby=self.webpackChunkkobi_gatsby||[]).push([[824],{2824:function(R,p,t){t.r(p);var e=t(7294),r=t(4462),f=t(6400),y=t(5828);const m=({})=>{let g=(0,e.useRef)(null);const h=()=>g.current.scrollIntoView();return e.createElement("div",{ref:g,className:"container"},e.createElement(y.Z,{title:"About"}),e.createElement("style",null,`
          body {
            margin: 0;
            font-family: "Open Sans", sans-serif;
            font-weight: 100;
          }
          
          a {
            color: black;
            text-decoration: none;
          }
          
          footer {
            margin: 0 0 20px 0;
          }
          
          .header {
            position: fixed;
            width: 100%;z-index: 100;
          }
          
          .pageTitle {
            background-color: #2d5750;
            color: white;
            text-align: center;
            font-size: 14px;
            padding: 5px 0px;
            font-weight: 600;
          }
          
          .paginationHeader {
            background-color: #d9d9d9;
            color: #2d5750;
            text-align: center;
            height: 20px;
            /* text-transform: uppercase; */
            font-size: 14px;
            font-weight: 600;
            padding: 5px 0px;
          }
          
          .searchHeader {
            background-color: #d9d9d9;
            color: #2d5750;
            text-align: center;
            /* text-transform: uppercase; */
            font-size: 14px;
            font-weight: 600;
            padding: 10px;
          }
          
          .pb0{
            padding-bottom: 0;
          }
          
          .contentContainer {
            padding: 45px 0 10px 0;
          }
          
          
          .contentContainer.withPagination {
            padding: 65px 0 10px 0;
          }
          
          .contentContainer.withPagination.search {
            padding: 80px 0 10px 0;
          }
          
          
          .contentContainer.search {
            padding: 60px 0 10px 0;
          }
          
          .innerContent {
            margin-left: auto;
            margin-right: auto;
            max-width: 480px;
          }
          
          
          .appContainer {
            display: flex;
            padding: 15px;
            cursor: pointer;
          }
          
          .appContainer:hover {
            background-color: #d9ffff;
          }
          
          .appIcon {
            height: 35px;
            width: 35px;
            object-fit: contain;
            margin-right: 10px;
          }
          
          .ph{
            padding: 0 10px;
          }
          
          .hide{
            display:none;
          }
          
          .navigationContainer{
            margin: 10px 0;
            display:flex;
            justify-content: space-evenly;
          }
          
          .pr {
            margin-right: 8px;
          }
          
          .footerButton {
            margin-bottom: 5px;
            padding: 8px;
            border: 2px solid teal;
            border-radius: 5px;
            color: teal;
            fill: teal;
            display: flex;
            flex:1;
            align-items: center;
            justify-content: center;
            cursor: pointer;
          }
          
          
          .footerButton.disabled {
            border: 2px solid grey;
            color: grey;
            fill: grey;
            cursor: pointer;
          }
          
          .footerButton:hover {
            border: 2px solid #2d5750;
            color: #2d5750;
            fill: #2d5750;
            background-color: #f0f0f0;
          }
          
          
          .footerButton:hover.disabled {
            border: 2px solid grey;
            color: grey;
            fill: grey;
            background-color: #ffffff;
            cursor:context-menu;
          }
          
          .footerIcon {
            height: 15px;
            width: 15px;
            margin-right: 10px;
            fill: #2d5750;
          }
          .footerIcon.right {
            height: 15px;
            width: 15px;
            margin-left: 10px;
            transform: rotateY(180deg);
          }                   
        `),e.createElement("header",null,e.createElement("div",{className:"pageTitle"},e.createElement("div",{className:"innerContent"},"ABOUT US"))),e.createElement("div",{className:"contentContainer pt"},e.createElement("div",{className:"postContent"},e.createElement("div",{className:"logoContainer2"}),e.createElement(f.Z,{sx:{fontSize:18,fontWeight:700,color:"teal"},component:"h1"},"Hi! I'm Kobi"),e.createElement("p",null,"Kobi reviews apps, especially for users of KaiOS phones."),e.createElement(f.Z,{sx:{fontSize:"1rem",fontWeight:500,color:"teal"},component:"h1"},"What are apps?"),e.createElement("p",null,"\u201DApp\u201D is short for \u201Cmobile application\u201D. Apps can help you do a variety of things, like message your friends (Whatsapp or Facebook), get information (Google Assistant), or just have fun playing games."),e.createElement(f.Z,{sx:{fontSize:"1rem",fontWeight:500,color:"teal"},component:"h1"},"Why use Kobi?"),e.createElement("p",null,"There are a lot of apps available, but not all of them are good! We test the apps, and find the best ones so you don\u2019t have to waste time downloading and trying different apps."),e.createElement("p",null,e.createElement(f.Z,{sx:{fontSize:"1rem",fontWeight:500,color:"teal"},component:"h1"},"Current Version:"),"Kobi v.1.2 (Updated 2023-10-31T02:56:43+00:00)"))),e.createElement("footer",null,e.createElement("div",{className:"innerContent"},e.createElement(r.Link,{to:"/"},e.createElement("div",{className:"footerButton"},e.createElement("svg",{className:"footerIcon",version:"1.1",id:"arrow-back",x:"0px",y:"0px",viewBox:"0 0 16 16"},e.createElement("g",{id:"arrow-back-icon"},e.createElement("path",{d:"M16,7H3.8l5.6-5.6L8,0L0,8l8,8l1.4-1.4L3.8,9H16V7z"}))),e.createElement("div",null,"Back to Home"))),e.createElement("div",{className:"footerButton",onClick:h},e.createElement("svg",{className:"footerIcon",x:"0px",y:"0px",viewBox:"0 0 16 16"},e.createElement("g",null,e.createElement("path",{d:"M0.5,8l1.41,1.41L7.5,3.83V16h2V3.83l5.58,5.59L16.5,8l-8-8L0.5,8z"}))),e.createElement("div",null,"Top of Page")))))};p.default=m},6400:function(R,p,t){t.d(p,{Z:function(){return Y}});var e=t(4425),r=t(6370),f=t(7294),y=t(1497),m=t(877),g=t(6530),h=t(8883),s=t(1430),i=t(370),l=t(132),a=t(5848);function S(C){return(0,a.Z)("MuiTypography",C)}const b=(0,l.Z)("MuiTypography",["root","h1","h2","h3","h4","h5","h6","subtitle1","subtitle2","body1","body2","inherit","button","caption","overline","alignLeft","alignRight","alignCenter","alignJustify","noWrap","gutterBottom","paragraph"]);var j=null,k=t(5893);const H=["align","className","component","gutterBottom","noWrap","paragraph","variant","variantMapping"],G=C=>{const{align:u,gutterBottom:Z,noWrap:o,paragraph:n,variant:x,classes:v}=C,c={root:["root",x,C.align!=="inherit"&&`align${(0,i.Z)(u)}`,Z&&"gutterBottom",o&&"noWrap",n&&"paragraph"]};return(0,g.Z)(c,S,v)},U=(0,h.ZP)("span",{name:"MuiTypography",slot:"Root",overridesResolver:(C,u)=>{const{ownerState:Z}=C;return[u.root,Z.variant&&u[Z.variant],Z.align!=="inherit"&&u[`align${(0,i.Z)(Z.align)}`],Z.noWrap&&u.noWrap,Z.gutterBottom&&u.gutterBottom,Z.paragraph&&u.paragraph]}})(({theme:C,ownerState:u})=>(0,r.Z)({margin:0},u.variant&&C.typography[u.variant],u.align!=="inherit"&&{textAlign:u.align},u.noWrap&&{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},u.gutterBottom&&{marginBottom:"0.35em"},u.paragraph&&{marginBottom:16})),$={h1:"h1",h2:"h2",h3:"h3",h4:"h4",h5:"h5",h6:"h6",subtitle1:"h6",subtitle2:"h6",body1:"p",body2:"p",inherit:"p"},q={primary:"primary.main",textPrimary:"text.primary",secondary:"secondary.main",textSecondary:"text.secondary",error:"error.main"},J=C=>q[C]||C;var Y=f.forwardRef(function(u,Z){const o=(0,s.Z)({props:u,name:"MuiTypography"}),n=J(o.color),x=(0,m.Z)((0,r.Z)({},o,{color:n})),{align:v="inherit",className:c,component:E,gutterBottom:D=!1,noWrap:O=!1,paragraph:M=!1,variant:T="body1",variantMapping:w=$}=x,W=(0,e.Z)(x,H),z=(0,r.Z)({},x,{align:v,color:n,className:c,component:E,gutterBottom:D,noWrap:O,paragraph:M,variant:T,variantMapping:w}),N=E||(M?"p":w[T]||$[T])||"span",Q=G(z);return(0,k.jsx)(U,(0,r.Z)({as:N,ref:Z,ownerState:z,className:(0,y.Z)(Q.root,c)},W))})},2275:function(R,p,t){var e=t(3888);const r=(0,e.Z)();p.Z=r},8883:function(R,p,t){t.d(p,{ZP:function(){return Z}});var e=t(4425),r=t(6370),f=t(4491),y=t(4189),m=t(1103);const g=["variant"];function h(o){return o.length===0}function s(o){const{variant:n}=o,x=(0,e.Z)(o,g);let v=n||"";return Object.keys(x).sort().forEach(c=>{c==="color"?v+=h(v)?o[c]:(0,m.Z)(o[c]):v+=`${h(v)?c:(0,m.Z)(c)}${(0,m.Z)(o[c].toString())}`}),v}var i=t(3366);const l=["name","slot","skipVariantsResolver","skipSx","overridesResolver"],a=["theme"],S=["theme"];function b(o){return Object.keys(o).length===0}function j(o){return typeof o=="string"&&o.charCodeAt(0)>96}const k=(o,n)=>n.components&&n.components[o]&&n.components[o].styleOverrides?n.components[o].styleOverrides:null,H=(o,n)=>{let x=[];n&&n.components&&n.components[o]&&n.components[o].variants&&(x=n.components[o].variants);const v={};return x.forEach(c=>{const E=s(c.props);v[E]=c.style}),v},G=(o,n,x,v)=>{var c,E;const{ownerState:D={}}=o,O=[],M=x==null||(c=x.components)==null||(E=c[v])==null?void 0:E.variants;return M&&M.forEach(T=>{let w=!0;Object.keys(T.props).forEach(W=>{D[W]!==T.props[W]&&o[W]!==T.props[W]&&(w=!1)}),w&&O.push(n[s(T.props)])}),O};function U(o){return o!=="ownerState"&&o!=="theme"&&o!=="sx"&&o!=="as"}const $=(0,y.Z)(),q=o=>o.charAt(0).toLowerCase()+o.slice(1);function J(o={}){const{defaultTheme:n=$,rootShouldForwardProp:x=U,slotShouldForwardProp:v=U}=o,c=E=>{const D=b(E.theme)?n:E.theme;return(0,i.Z)((0,r.Z)({},E,{theme:D}))};return c.__mui_systemSx=!0,(E,D={})=>{(0,f.Co)(E,B=>B.filter(I=>!(I!=null&&I.__mui_systemSx)));const{name:O,slot:M,skipVariantsResolver:T,skipSx:w,overridesResolver:W}=D,z=(0,e.Z)(D,l),N=T!==void 0?T:M&&M!=="Root"||!1,Q=w||!1;let ne,F=U;M==="Root"?F=x:M?F=v:j(E)&&(F=void 0);const X=(0,f.ZP)(E,(0,r.Z)({shouldForwardProp:F,label:ne},z)),te=(B,...I)=>{const K=I?I.map(d=>typeof d=="function"&&d.__emotion_real!==d?P=>{let{theme:L}=P,V=(0,e.Z)(P,a);return d((0,r.Z)({theme:b(L)?n:L},V))}:d):[];let A=B;O&&W&&K.push(d=>{const P=b(d.theme)?n:d.theme,L=k(O,P);if(L){const V={};return Object.entries(L).forEach(([re,_])=>{V[re]=typeof _=="function"?_((0,r.Z)({},d,{theme:P})):_}),W(d,V)}return null}),O&&!N&&K.push(d=>{const P=b(d.theme)?n:d.theme;return G(d,H(O,P),P,O)}),Q||K.push(c);const oe=K.length-I.length;if(Array.isArray(B)&&oe>0){const d=new Array(oe).fill("");A=[...B,...d],A.raw=[...B.raw,...d]}else typeof B=="function"&&B.__emotion_real!==B&&(A=d=>{let{theme:P}=d,L=(0,e.Z)(d,S);return B((0,r.Z)({theme:b(P)?n:P},L))});return X(A,...K)};return X.withConfig&&(te.withConfig=X.withConfig),te}}var ee=t(2275);const Y=o=>U(o)&&o!=="classes",C=null;var Z=J({defaultTheme:ee.Z,rootShouldForwardProp:Y})},1430:function(R,p,t){t.d(p,{Z:function(){return h}});var e=t(6370);function r(s,i){const l=(0,e.Z)({},i);return Object.keys(s).forEach(a=>{if(a.toString().match(/^(components|slots)$/))l[a]=(0,e.Z)({},s[a],l[a]);else if(a.toString().match(/^(componentsProps|slotProps)$/)){const S=s[a]||{},b=i[a];l[a]={},!b||!Object.keys(b)?l[a]=S:!S||!Object.keys(S)?l[a]=b:(l[a]=(0,e.Z)({},b),Object.keys(S).forEach(j=>{l[a][j]=r(S[j],b[j])}))}else l[a]===void 0&&(l[a]=s[a])}),l}function f(s){const{theme:i,name:l,props:a}=s;return!i||!i.components||!i.components[l]||!i.components[l].defaultProps?a:r(i.components[l].defaultProps,a)}var y=t(8097);function m({props:s,name:i,defaultTheme:l}){const a=(0,y.Z)(l);return f({theme:a,name:i,props:s})}var g=t(2275);function h({props:s,name:i}){return m({props:s,name:i,defaultTheme:g.Z})}},370:function(R,p,t){var e=t(1103);p.Z=e.Z},6530:function(R,p,t){t.d(p,{Z:function(){return e}});function e(r,f,y=void 0){const m={};return Object.keys(r).forEach(g=>{m[g]=r[g].reduce((h,s)=>{if(s){const i=f(s);i!==""&&h.push(i),y&&y[s]&&h.push(y[s])}return h},[]).join(" ")}),m}},5848:function(R,p,t){t.d(p,{Z:function(){return f}});var e=t(1864);const r={active:"active",checked:"checked",completed:"completed",disabled:"disabled",readOnly:"readOnly",error:"error",expanded:"expanded",focused:"focused",focusVisible:"focusVisible",required:"required",selected:"selected"};function f(y,m,g="Mui"){const h=r[m];return h?`${g}-${h}`:`${e.Z.generate(y)}-${m}`}},132:function(R,p,t){t.d(p,{Z:function(){return r}});var e=t(5848);function r(f,y,m="Mui"){const g={};return y.forEach(h=>{g[h]=(0,e.Z)(f,h,m)}),g}}}]);

//# sourceMappingURL=824-be118647358be982a580.js.map